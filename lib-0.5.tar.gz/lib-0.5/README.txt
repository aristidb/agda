------------------------------------------------------------------------
The Agda standard library
------------------------------------------------------------------------

For information about the library, see README.agda.

The README module imports the Everything module. This module is
generated automatically; if you have downloaded the library from its
darcs repository and want to type check README you can construct
Everything by running "cabal install && GenerateEverything".

Note that all library sources are located under src. The modules
README, README.* and Everything are not really part of the library, so
these modules are located in the top-level directory instead.
